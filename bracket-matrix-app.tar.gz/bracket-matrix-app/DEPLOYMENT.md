# 🚀 Deployment & Update Guide

## Quick Update Instructions

### Every Day/Week (Keep Data Fresh)

**Method 1: Automatic Scraping** (Recommended if you have network access)
```bash
cd bracket-matrix-app/backend
python3 scraper.py
```

**Method 2: Manual Update**
1. Visit http://www.bracketmatrix.com/
2. Copy the table data
3. Edit `backend/bracket_data.json`
4. Restart the API server

**Method 3: Scheduled Updates** (Set it and forget it)
```bash
# Add to crontab for automatic hourly updates
crontab -e

# Add this line:
0 * * * * cd /path/to/bracket-matrix-app/backend && /usr/bin/python3 scraper.py
```

---

## Full Deployment to Production

### Option 1: Deploy to Heroku (Free/Easy)

#### Backend API

1. **Install Heroku CLI**
```bash
curl https://cli-assets.heroku.com/install.sh | sh
```

2. **Create Heroku app**
```bash
cd backend
heroku create your-bracket-api
```

3. **Add Procfile**
Create `backend/Procfile`:
```
web: gunicorn api:app
```

4. **Add gunicorn to requirements**
Add to `requirements.txt`:
```
gunicorn==21.2.0
```

5. **Deploy**
```bash
git init
git add .
git commit -m "Deploy bracket API"
git push heroku main
```

6. **Set up auto-updates**
Use Heroku Scheduler add-on:
```bash
heroku addons:create scheduler:standard
heroku addons:open scheduler
```
Add job: `python scraper.py` (runs hourly)

#### Frontend

1. **Update API URL in index.html**
```javascript
const API_URL = 'https://your-bracket-api.herokuapp.com/api';
```

2. **Deploy to Netlify**
```bash
# Install Netlify CLI
npm install -g netlify-cli

# Deploy
cd frontend
netlify deploy --prod
```

---

### Option 2: Deploy to AWS

#### Backend (Elastic Beanstalk)

1. **Install AWS CLI and EB CLI**
```bash
pip install awsebcli
```

2. **Initialize EB application**
```bash
cd backend
eb init -p python-3.11 bracket-matrix-api
```

3. **Create environment**
```bash
eb create production
```

4. **Set up CloudWatch for scheduled updates**
Create Lambda function that calls scraper every hour

#### Frontend (S3 + CloudFront)

1. **Create S3 bucket**
```bash
aws s3 mb s3://bracket-matrix-frontend
```

2. **Upload frontend**
```bash
cd frontend
aws s3 sync . s3://bracket-matrix-frontend --acl public-read
```

3. **Enable static website hosting**
```bash
aws s3 website s3://bracket-matrix-frontend --index-document index.html
```

4. **Set up CloudFront** (for HTTPS and caching)

---

### Option 3: Deploy to DigitalOcean

#### Backend (App Platform)

1. **Create DigitalOcean account**
2. **Connect GitHub repo**
3. **Configure build settings**:
   - Build command: `pip install -r requirements.txt`
   - Run command: `gunicorn --bind :8080 api:app`

#### Frontend (Static Site)

1. **Upload to App Platform**
2. **Configure as static site**
3. **Update API URL** in index.html

---

### Option 4: Deploy to Your Own VPS

#### Backend Setup

1. **Install Python and dependencies**
```bash
sudo apt update
sudo apt install python3 python3-pip nginx
pip3 install -r requirements.txt
```

2. **Create systemd service**
Create `/etc/systemd/system/bracket-api.service`:
```ini
[Unit]
Description=Bracket Matrix API
After=network.target

[Service]
User=www-data
WorkingDirectory=/var/www/bracket-matrix/backend
ExecStart=/usr/bin/python3 /var/www/bracket-matrix/backend/api.py
Restart=always

[Install]
WantedBy=multi-user.target
```

3. **Start service**
```bash
sudo systemctl start bracket-api
sudo systemctl enable bracket-api
```

4. **Configure Nginx**
Create `/etc/nginx/sites-available/bracket-matrix`:
```nginx
server {
    listen 80;
    server_name api.yourdomain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

Enable site:
```bash
sudo ln -s /etc/nginx/sites-available/bracket-matrix /etc/nginx/sites-enabled/
sudo systemctl reload nginx
```

#### Frontend Setup

1. **Copy frontend files**
```bash
sudo cp -r frontend/* /var/www/html/
```

2. **Update API URL** in index.html

3. **Set up SSL with Let's Encrypt**
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

---

## Automatic Data Updates

### Using Cron (Linux/Mac)

```bash
# Edit crontab
crontab -e

# Add these lines:

# Update every hour during basketball season
0 * * * * cd /path/to/bracket-matrix-app/backend && python3 scraper.py

# Update every 30 minutes on Selection Sunday
*/30 * * * * cd /path/to/bracket-matrix-app/backend && python3 scraper.py
```

### Using Task Scheduler (Windows)

1. Open Task Scheduler
2. Create Basic Task
3. Trigger: Daily, repeat every 1 hour
4. Action: Start Program
   - Program: `python`
   - Arguments: `C:\path\to\scraper.py`
   - Start in: `C:\path\to\backend`

### Using GitHub Actions (Automated)

Create `.github/workflows/update-data.yml`:
```yaml
name: Update Bracket Data

on:
  schedule:
    - cron: '0 * * * *'  # Every hour
  workflow_dispatch:  # Manual trigger

jobs:
  update:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Set up Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.11'
      
      - name: Install dependencies
        run: |
          cd backend
          pip install -r requirements.txt
      
      - name: Run scraper
        run: |
          cd backend
          python scraper.py
      
      - name: Commit changes
        run: |
          git config --local user.email "action@github.com"
          git config --local user.name "GitHub Action"
          git add backend/bracket_data.json
          git commit -m "Update bracket data" || echo "No changes"
          git push
```

---

## Monitoring & Maintenance

### Check API Health

```bash
curl https://your-api-url.com/health
```

### View Logs

**Heroku**:
```bash
heroku logs --tail
```

**Systemd**:
```bash
sudo journalctl -u bracket-api -f
```

### Update Dependencies

```bash
cd backend
pip install -r requirements.txt --upgrade
pip freeze > requirements.txt
```

---

## Troubleshooting

### Issue: Scraper not working

**Solution**:
1. Check network connectivity
2. Verify BracketMatrix.com is accessible
3. Check if site structure changed
4. Manually update `bracket_data.json`

### Issue: CORS errors in frontend

**Solution**:
1. Verify API has CORS enabled (check `api.py`)
2. Ensure API URL is correct in frontend
3. Check browser console for specific error

### Issue: API not responding

**Solution**:
1. Check if API server is running: `ps aux | grep api.py`
2. Verify port 5000 is not in use: `lsof -i :5000`
3. Check API logs for errors
4. Restart API server

---

## Performance Optimization

### Enable Caching

Add to `api.py`:
```python
from flask_caching import Cache

cache = Cache(app, config={'CACHE_TYPE': 'simple'})

@app.route('/api/brackets')
@cache.cached(timeout=300)  # Cache for 5 minutes
def get_brackets():
    # ...
```

### Compress Responses

Add to `api.py`:
```python
from flask_compress import Compress

Compress(app)
```

### Use CDN for Frontend

Upload static assets to CDN for faster loading worldwide.

---

## Security Recommendations

1. **Use HTTPS**: Always use SSL certificates in production
2. **Rate Limiting**: Add rate limiting to API endpoints
3. **Environment Variables**: Store sensitive config in env vars
4. **Input Validation**: Validate all user inputs
5. **CORS**: Only allow your frontend domain

---

## Cost Estimates

### Free Tier Options
- **Heroku**: Free for API (with limits)
- **Netlify**: Free for frontend
- **GitHub Pages**: Free for frontend
- **Total**: $0/month

### Low-Cost Options
- **DigitalOcean**: $5/month (Droplet)
- **AWS Free Tier**: Free for 12 months
- **Vercel**: Free for small projects

### Production Setup
- **DigitalOcean**: $10-20/month
- **AWS**: $10-30/month
- **Domain**: $10-15/year

---

## Support

If you encounter issues:

1. Check the README.md for basic troubleshooting
2. Review API logs for error messages
3. Test API endpoints directly with curl
4. Verify data format in bracket_data.json
5. Check browser console for frontend errors
