#!/bin/bash

echo "======================================"
echo "  Bracket Matrix - Quick Start"
echo "======================================"
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi

echo "✅ Python found: $(python3 --version)"
echo ""

# Install backend dependencies
echo "📦 Installing backend dependencies..."
cd backend
pip install -r requirements.txt --quiet
echo "✅ Backend dependencies installed"
echo ""

# Run the scraper (if network is available)
echo "🔄 Attempting to fetch latest bracket data..."
python3 scraper.py
echo ""

# Start the API server in the background
echo "🚀 Starting API server..."
python3 api.py &
API_PID=$!
echo "✅ API server started (PID: $API_PID)"
echo ""

# Wait for server to start
sleep 3

# Open the frontend
echo "🌐 Opening frontend..."
cd ../frontend

# Try to open in default browser
if command -v xdg-open &> /dev/null; then
    xdg-open index.html
elif command -v open &> /dev/null; then
    open index.html
else
    echo "📝 Please open frontend/index.html in your browser"
fi

echo ""
echo "======================================"
echo "  Application is running!"
echo "======================================"
echo ""
echo "API Server: http://localhost:5000"
echo "Frontend: Open frontend/index.html in your browser"
echo ""
echo "To stop the API server, run: kill $API_PID"
echo ""
echo "Press Ctrl+C to stop this script"
echo ""

# Keep script running
wait $API_PID
