#!/usr/bin/env python3
"""
Bracket Matrix Data Scraper
Fetches the latest NCAA tournament bracket predictions
"""

import requests
from bs4 import BeautifulSoup
import json
import re
from datetime import datetime
import sys

def scrape_bracket_matrix():
    """Scrape the main Bracket Matrix page and extract all bracket data"""
    
    url = 'http://www.bracketmatrix.com/'
    
    print(f"Fetching data from {url}...")
    
    try:
        response = requests.get(url, timeout=15, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        response.raise_for_status()
        print("✅ Successfully fetched page")
    except requests.RequestException as e:
        print(f"❌ Error fetching data: {e}")
        print("\nNote: You can manually update bracket_data.json with data from the website")
        return None
    
    soup = BeautifulSoup(response.content, 'html.parser')
    
    # Find the main data table
    table = soup.find('table')
    if not table:
        print("❌ Could not find main table")
        return None
    
    print("✅ Found data table")
    
    rows = table.find_all('tr')
    print(f"✅ Found {len(rows)} rows")
    
    # Extract header row (bracketologist names)
    header_row = rows[0]
    header_cells = header_row.find_all(['td', 'th'])
    
    # Parse bracketologist info from headers
    bracketologists = []
    for cell in header_cells[5:]:  # Skip first 5 columns (rank, team, conf, avg seed, count)
        text = cell.get_text(strip=True)
        link = cell.find('a')
        if link and text:
            bracketologists.append({
                'name': text,
                'url': link.get('href', '')
            })
        elif text and text not in ['', ' ']:  # Some might not have links
            bracketologists.append({
                'name': text,
                'url': ''
            })
    
    print(f"✅ Found {len(bracketologists)} bracketologists")
    
    # Extract update date info
    if len(rows) > 1:
        update_date_row = rows[1]
        date_cells = update_date_row.find_all(['td', 'th'])
        update_dates = []
        for cell in date_cells[5:]:
            date_text = cell.get_text(strip=True)
            update_dates.append(date_text if date_text else '')
    else:
        update_dates = [''] * len(bracketologists)
    
    # Extract team data
    teams = []
    start_row = 2 if len(rows) > 2 else 1
    
    for row in rows[start_row:]:  # Skip header rows
        cells = row.find_all(['td', 'th'])
        if len(cells) < 5:
            continue
        
        # Extract basic team info
        seed = cells[0].get_text(strip=True)
        team_name = cells[1].get_text(strip=True)
        conference = cells[2].get_text(strip=True)
        avg_seed = cells[3].get_text(strip=True)
        num_brackets = cells[4].get_text(strip=True)
        
        # Skip empty rows
        if not team_name or team_name == '':
            continue
        
        # Extract individual bracket predictions
        predictions = []
        for cell in cells[5:]:
            pred = cell.get_text(strip=True)
            # Convert empty strings to None for cleaner JSON
            predictions.append(pred if pred and pred != '' else None)
        
        teams.append({
            'seed': seed,
            'team': team_name,
            'conference': conference,
            'average_seed': avg_seed,
            'num_brackets': num_brackets,
            'predictions': predictions[:len(bracketologists)]  # Match length
        })
    
    print(f"✅ Extracted data for {len(teams)} teams")
    
    # Compile full dataset
    data = {
        'last_updated': datetime.now().isoformat(),
        'source_url': url,
        'bracketologists': bracketologists,
        'update_dates': update_dates[:len(bracketologists)],
        'teams': teams
    }
    
    return data


def save_to_json(data, filename='bracket_data.json'):
    """Save scraped data to JSON file"""
    with open(filename, 'w') as f:
        json.dump(data, indent=2, fp=f)
    print(f"Data saved to {filename}")


if __name__ == '__main__':
    print("Scraping Bracket Matrix...")
    data = scrape_bracket_matrix()
    
    if data:
        print(f"Successfully scraped data for {len(data['teams'])} teams")
        print(f"Found {len(data['bracketologists'])} bracketologists")
        save_to_json(data)
        
        # Print sample
        print("\nSample team data:")
        for team in data['teams'][:3]:
            print(f"  {team['team']} - Avg Seed: {team['average_seed']}")
    else:
        print("Failed to scrape data")
